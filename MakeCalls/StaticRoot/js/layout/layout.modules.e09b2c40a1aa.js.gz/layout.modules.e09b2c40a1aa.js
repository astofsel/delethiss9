(function () {
  'use strict';

  angular
    .module('mainApp.progressCircular', [
      'mainApp.progressCircular'
    ]);

  angular
    .module('mainApp.progressCircular', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
})();