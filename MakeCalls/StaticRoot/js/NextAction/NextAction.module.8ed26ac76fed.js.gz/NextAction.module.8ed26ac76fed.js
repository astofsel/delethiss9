(function () {
  'use strict';

  angular
    .module('mainApp.NextAction', [
      'mainApp.NextAction.controllers', 
      'mainApp.NextAction.services',
    ]);

  angular
    .module('mainApp.NextAction.controllers', []);

      angular
    .module('mainApp.NextAction.services', []);

})();