(function () {
  'use strict';

  angular
    .module('mainApp.Opportunities', [
      'mainApp.Opportunities.controllers', 
    ]);

  angular
    .module('mainApp.Opportunities.controllers', []);

})();