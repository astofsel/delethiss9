(function () {
  'use strict';

  angular
    .module('mainApp.List', [
      'mainApp.List.controllers'
    ]);

  angular
    .module('mainApp.List.controllers', []);
    
})();