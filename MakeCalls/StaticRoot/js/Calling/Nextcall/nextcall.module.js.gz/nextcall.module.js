(function () {
  'use strict';

  angular
    .module('mainApp.Nextcall', [
      'mainApp.Nextcall.controllers'
    ]);

  angular
    .module('mainApp.Nextcall.controllers', []);

})();