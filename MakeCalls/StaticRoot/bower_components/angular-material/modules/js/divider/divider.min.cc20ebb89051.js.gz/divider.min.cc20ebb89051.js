/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v1.1.0-master-2b98560
 */
!function(i,e,n){"use strict";function r(i){return{restrict:"E",link:i}}r.$inject=["$mdTheming"],e.module("material.components.divider",["material.core"]).directive("mdDivider",r)}(window,window.angular);